package com.example.myhw.plan;

import com.example.myhw.base.BaseBindingActivity;
import com.example.myhw.databinding.ActivityPlanDetailBinding;

public class PlanDetailActivity extends BaseBindingActivity<ActivityPlanDetailBinding> {
    @Override
    protected void initListener() {

    }

    @Override
    protected void initData() {

    }
}
